
<! Doctype html>
<html>
<head>
<!--Designed By Khaja-->
<meta charset="utf-8">
<title>Login</title>
<meta name="viewport" content="width=device-width , initial-scale =1">
<!-- Style.Css Link-->
<link href="css/style1.css" type="text/css" rel="stylesheet">
<!--Bootstrap CDN-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<!--Fontawesome CDN-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--Google Fonts CDN-->
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Lato|Montserrat|Raleway|Roboto" rel="stylesheet">
    <style>
    .input-group-addon{ border-bottom: 1px solid #ccc !important;color: #fff; padding: 10px}
    .login-body{background-image: url(img/login-bg.jpg);background-size: 100% 100% }
    .bg-wl{    background: linear-gradient(to bottom, rgba(19, 101, 147, 0.5803921568627451) 0%, rgb(81, 102, 124) 100%);}
        .form-control{     color: #FDFCFD;   border-bottom: 1px solid #ccc !important;border-left: none !important;border-right: none !important;border-top: none !important;background-color: transparent !important}
       .overlay{background-color: rgba(0,0,0,0.5);}
        .form-control:focus{color: #fff !important;box-shadow: none!important}
    </style>
</head>
<body class="login-body">
<div class="overlay">
<!-- Content Section Start-->
    <section>
   <div class="container-fluid font5">
     <div class="container">
         <div class="clearfix">&nbsp;</div>
         <div class="clearfix">&nbsp;</div>
         <div class="clearfix">&nbsp;</div>
         <div class="clearfix">&nbsp;</div>          <div class="clearfix">&nbsp;</div>
       <div class="row">
       <div class="col-sm-4 offset-sm-4 bg-wl no-padd card">
           <div class="text-center">
               <div class="clearfix">&nbsp;</div>
           <img src="img/logo.png" class="img-fluid" style="width: 78%;padding:10px">
               </div>
         
<form>
        <div style="padding:0px 2px">
<div class="form-group col-sm-12">
 <div class="input-group">
    <div class="input-group-addon">
      &nbsp; <i class="fa fa-user"></i> &nbsp;
    </div>
    <input class="form-control" value="Username" type="text"/>
  </div>
</div>
<!--<div class="form-group col-sm-12">
 <div class="input-group">
    <div class="input-group-addon">
      &nbsp; <i class="fa fa-user"></i> &nbsp;
    </div>
    <input class="form-control" value="Mobile" type="text"/>
  </div>
</div>-->
               
<div class="form-group col-sm-12">
<div class="input-group">
    <div class="input-group-addon">
     &nbsp; <i class="fa fa-lock" aria-hidden="true"></i> &nbsp;
    </div>
    <input class="form-control" value="Password" type="password"/>
  </div>
</div>
            <div class="clearfix">&nbsp;</div>
                 <div class="checkbox col-sm-12">
                     <label>
                 <input type="checkbox" class="from-control "><span class="col-wh" style="color:#fff"> Remember Me</span> </label>
                      <span class="float-right font14"><a href="#">Forgot password?</a></span>
                 </div>
           
                   <div class="clearfix">&nbsp;</div>  
                 <div class="text-center">
                 <button type="button" class="btn btn-danger col-sm-12 no-bod-rad">Signin</button>
                     </div>
                     <div class="clearfix">&nbsp;</div>  
<!--
            <hr>
            <p class="text-center">Don't have an account.? <a href="#"> SignUp here</a></p>
-->
            </div>
                 </form>
            </div>  
      
            </div>
        </div>
     </div>
</section>
     <div class="clearfix">&nbsp;</div>  <div class="clearfix">&nbsp;</div>  <div class="clearfix">&nbsp;</div>  <div class="clearfix">&nbsp;</div>  <div class="clearfix">&nbsp;</div> 
    </div>
<!-- Content Section end-->
<!-- Bootstarp Scripts-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    </body>
   </html>
